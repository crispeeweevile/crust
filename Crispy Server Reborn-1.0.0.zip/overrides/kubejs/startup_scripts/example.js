// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded startup scripts)')

StartupEvents.registry('item', e => {
  // The texture for this item has to be placed in kubejs/assets/kubejs/textures/item/test_item.png
  // If you want a custom item model, you can create one in Blockbench and put it in kubejs/assets/kubejs/models/item/test_item.json
	e.create('copper').displayName('Copper').tooltip("Value: 0.0625g").fireResistant(true)
	e.create('bronze').displayName('Bronze').tooltip("Value: 0.2500g").fireResistant(true)
	e.create('tungsten').displayName('Tungsten').tooltip("Value: 1.0000g").fireResistant(true)
	e.create('silver').displayName('Silver').tooltip("Value: 4.0000g").fireResistant(true)
	e.create('gold').displayName('Gold').tooltip("Value: 16.000g").fireResistant(true)
	e.create('royal_gold').displayName('Royal Gold').tooltip("Value: 64.000g").fireResistant(true)
	e.create('celestial_token').displayName('Celestial Token').tooltip("What is it???").rarity('epic').glow(true).fireResistant(true)
})