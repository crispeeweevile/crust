// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded server scripts)')

ServerEvents.recipes(event => {
  // You can replace `event` with any name you like, as
  // long as you change it inside the callback too!

  // This part, inside the curly braces, is the callback.
  // You can modify as many recipes as you like in here,
  // without needing to use ServerEvents.recipes() again.
  // event.remove({output: 'create_new_age:thorium'})
  event.remove({output: 'create_dd:furnace_engine'})
  event.remove({output: 'create_dd:kinetic_motor'})
  event.remove({output: 'create_dd:accelerator_motor'})
  event.remove({output: 'create_dd:flywheel'})
  event.remove({output: 'createaddition:alternator'})
  event.remove({output: 'createaddition:electric_motor'})
  event.remove({output: 'createaddition:connector'})
  event.remove({output: 'createaddition:small_light_connector'})
  event.remove({output: 'createaddition:large_connector'})
  event.remove({output: 'createaddition:redstone_relay'})
  event.remove({output: 'createaddition:large_connector'})
  event.remove({output: 'magistuarmory:wood_flamebladedsword'})
  event.remove({output: 'magistuarmory:stone_flamebladedsword'})
  event.remove({output: 'magistuarmory:iron_flamebladedsword'})
  event.remove({output: 'magistuarmory:gold_flamebladedsword'})
  event.remove({output: 'magistuarmory:diamond_flamebladedsword'})
  event.remove({output: 'magistuarmory:netherite_flamebladedsword'})
  event.remove({output: 'magistuarmory:copper_flamebladedsword'})
  event.remove({output: 'magistuarmory:steel_flamebladedsword'})
  event.remove({output: 'magistuarmory:silver_flamebladedsword'})
  event.remove({output: 'magistuarmory:tin_flamebladedsword'})
  event.remove({output: 'magistuarmory:bronze_flamebladedsword'})
  event.shapeless(
    Item.of('kubejs:bronze', 1), // arg 1: output
    [
      '4x kubejs:copper'
    ]
  )
  event.shapeless(
    Item.of('kubejs:tungsten', 1), // arg 1: output
    [
      '4x kubejs:bronze'
    ]
  )
  event.shapeless(
    Item.of('kubejs:silver', 1), // arg 1: output
    [
      '4x kubejs:tungsten'
    ]
  )
  event.shapeless(
    Item.of('kubejs:gold', 1), // arg 1: output
    [
      '4x kubejs:silver'
    ]
  )
  event.shapeless(
    Item.of('kubejs:royal_gold', 1), // arg 1: output
    [
      '4x kubejs:gold'
    ]
  )


  event.shapeless(
    Item.of('kubejs:copper', 4), // arg 1: output
    [
      'kubejs:bronze'
    ]
  )
  event.shapeless(
    Item.of('kubejs:bronze', 4), // arg 1: output
    [
      'kubejs:tungsten'
    ]
  )
  event.shapeless(
    Item.of('kubejs:tungsten', 4), // arg 1: output
    [
      'kubejs:silver'
    ]
  )
  event.shapeless(
    Item.of('kubejs:silver', 4), // arg 1: output
    [
      'kubejs:gold'
    ]
  )
  event.shapeless(
    Item.of('kubejs:gold', 4), // arg 1: output
    [
      'kubejs:royal_gold'
    ]
  )

  console.log('Hello! The recipe event has fired!')
})